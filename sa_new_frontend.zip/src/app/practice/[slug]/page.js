import { client } from '@/lib/sanity';
import { PortableText } from '@portabletext/react';
import Link from 'next/link';
import { notFound } from 'next/navigation';

// 1. Metadata Generation
export async function generateMetadata({ params }) {
  const { slug } = await params;
  
  const practice = await client.fetch(`*[_type == "practiceArea" && slug.current == $slug][0]`, { slug });
  
  if (!practice) return { title: 'Practice Area Not Found' };

  return {
    title: `${practice.title} | S&A Law Chambers`,
    description: practice.description || `Legal expertise in ${practice.title}.`,
  };
}

// 2. Main Page Component
export default async function PracticeTemplate({ params }) {
  const { slug } = await params;

  const practice = await client.fetch(`
    *[_type == "practiceArea" && slug.current == $slug][0]{
      title,
      description, 
      content
    }
  `, { slug });

  if (!practice) {
    notFound();
  }

  // Dummy FAQ Data (Lorem Ipsum)
  const faqs = [
    {
      question: "Lorem ipsum dolor sit amet, consectetur adipiscing elit?",
      answer: "Sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat."
    },
    {
      question: "Ut enim ad minim veniam, quis nostrud exercitation?",
      answer: "Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum."
    },
    {
      question: "Duis aute irure dolor in reprehenderit in voluptate?",
      answer: "Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt."
    },
    {
      question: "Excepteur sint occaecat cupidatat non proident?",
      answer: "Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem."
    }
  ];

  return (
    <main className="bg-white min-h-screen">
      
      {/* A. HERO SECTION */}
      <section className="relative h-[45vh] flex items-center justify-center bg-brand-900 overflow-hidden">
        <div className="absolute inset-0 opacity-10 bg-[url('https://www.transparenttextures.com/patterns/cubes.png')]"></div>
        <div className="absolute -top-20 -right-20 w-96 h-96 border border-brand-gold/20 rounded-full blur-sm"></div>

        <div className="relative z-10 text-center px-6 max-w-4xl">
          <span className="text-brand-gold text-xs font-bold tracking-[0.3em] uppercase mb-4 block">
            Expertise
          </span>
          <h1 className="text-4xl md:text-6xl font-serif font-bold text-white tracking-wide mb-6">
            {practice.title}
          </h1>
          <div className="h-1 w-24 bg-brand-gold mx-auto shadow-[0_0_15px_rgba(197,160,89,0.6)]"></div>
        </div>
      </section>

      {/* B. MAIN CONTENT */}
      <section className="container mx-auto px-6 py-20 max-w-4xl">
        <div className="mb-12 text-sm text-slate-400 font-medium">
          <Link href="/" className="hover:text-brand-gold transition-colors">Home</Link> 
          <span className="mx-2">/</span>
          <Link href="/#practice-areas" className="hover:text-brand-gold transition-colors">Practice Areas</Link>
          <span className="mx-2">/</span>
          <span className="text-brand-900 font-bold">{practice.title}</span>
        </div>

        <div className="prose prose-lg prose-slate max-w-none font-sans text-brand-700 leading-relaxed text-justify">
          {practice.content ? (
            <PortableText 
              value={practice.content} 
              components={{
                block: {
                  normal: ({children}) => <p className="mb-6">{children}</p>,
                  h3: ({children}) => <h3 className="text-2xl font-serif text-brand-900 mt-10 mb-4">{children}</h3>
                },
                list: {
                  bullet: ({children}) => <ul className="list-disc pl-5 mb-6 space-y-2">{children}</ul>
                }
              }}
            />
          ) : (
            <p className="text-slate-400 italic">Content coming soon...</p>
          )}
        </div>

        {/* CTA Section */}
        <div className="mt-16 border-t border-slate-200 pt-10">
          <div className="bg-brand-cream border-l-4 border-brand-gold p-8 rounded-r-sm">
            <h3 className="font-serif text-xl text-brand-900 mb-2">Need advice on {practice.title}?</h3>
            <p className="text-sm text-brand-700 mb-6">
              Our team represents clients before the Supreme Court and High Courts in complex matters.
            </p>
            <Link 
              href="/contact" 
              className="text-xs font-bold uppercase tracking-widest text-brand-900 border-b border-brand-900 hover:text-brand-gold hover:border-brand-gold transition-all pb-1"
            >
              Book a Consultation →
            </Link>
          </div>
        </div>

        {/* NEW: FAQ SECTION */}
        <div className="mt-20">
          <h3 className="text-3xl font-serif text-brand-900 mb-8 pb-4 border-b border-slate-200">
            Common Questions
          </h3>
          
          <div className="space-y-4">
            {faqs.map((faq, index) => (
              <details key={index} className="group bg-slate-50 border border-slate-100 rounded-sm">
                <summary className="flex justify-between items-center font-serif font-medium cursor-pointer list-none p-6 text-brand-900 hover:text-brand-gold transition-colors">
                  <span>{faq.question}</span>
                  <span className="transition group-open:rotate-180">
                    <svg fill="none" height="24" shapeRendering="geometricPrecision" stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" viewBox="0 0 24 24" width="24"><path d="M6 9l6 6 6-6"></path></svg>
                  </span>
                </summary>
                <div className="text-slate-600 font-sans text-sm leading-relaxed px-6 pb-6">
                  {faq.answer}
                </div>
              </details>
            ))}
          </div>
        </div>

      </section>
    </main>
  );
}